//
//  Array+Extension.swift
//  YouTube
//
//  Created by Kamal Harariya on 3/18/18.
//  Copyright © 2018 company. All rights reserved.
//

import Foundation

//extension Array<T: Equatable> {
//    
//    func index(of element: T) -> Int? {
//        
//    }
//}

